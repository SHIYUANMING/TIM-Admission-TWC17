function [Nres, sparsity,user_adm] = sparse_induce(K, r, params, V)

    % Input 
%     if ~exist('K', 'var') || isempty(K)
%         K = 10;
%     end
%     if ~exist('r', 'var') || isempty(r)
%         r = 2;
%     end
%     
%     if ~exist('params','var') ||  isempty(params) || nargin == 2
%         params = [];
%     end
    
%     if ~isfield(params,'rho'); params.rho = 1e-1; end; 
%     if ~isfield(params,'eps'); params.eps =1e-4; end;
%     if ~isfield(params,'verbosity'); params.verbosity = 2; end; 
    
    rho = params.rho;
    eps = params.eps;

    lambda = params.lambda;
    
    %% Step 1: finding the sparsity pattern.
    if params.verbosity > 0
        fprintf('\n\t\t\t\t Step 1: finding the sparsity pattern.\n\n');
    end
    
    % Pick the manifold of fixed-rank matrices
    problem.M = fixedrankfactory_2factors_preconditioned(K, K, r); % Suits well to the diagonal constraint.

    
    problem.cost = @cost;
    function f = cost(x)
        L = x.L;
        R = x.R;
        
        f = -rho*sum(sum(((diag(L*R')).^2+eps^2).^(0.5))) ...
            + 0.5*norm(V.*(L*R'), 'fro')^2 ...
            + rho*lambda*norm(diag(L*R'), 'fro')^2;
  
    end
    
    problem.egrad = @egrad;
    function grad = egrad(x)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        
        grad.L = (diag(M) + S)*R;
        grad.R = (diag(M) + S)'*L;
    end
    
    problem.ehess = @ehess;
    function ehess = ehess(x, eta)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        Mdot = -rho*(LRt_sq_eps - xpowy2(3,LRt_sq_eps).*LRt_sq).*(diag(L*eta.R'+ eta.L*R'));
     
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        Sdot = V.*(L*eta.R'+ eta.L*R') +2*rho*lambda*diag(diag(L*eta.R'+ eta.L*R'));
        
        ehess.L = (diag(M) + S)*eta.R + (diag(Mdot)   +  Sdot)*R;
        ehess.R = (diag(M) + S)'*eta.L + (diag(Mdot') +  Sdot')*L;
    end
    
    %     % Check consistency of the gradient
    %     checkgradient(problem); pause;
    %     checkhessian(problem); pause;
    
    options.maxiter = params.maxiter;
    options.verbosity = params.verbosity;
    
    [xopt,~, infos_step1, ~] = trustregions(problem, [], options);
    Xopt = xopt.L*xopt.R';
    allusers = 1:1:K;
    user_adm = allusers(abs(diag(Xopt))>1e-3);
    sparsity = length(user_adm);
    
    Diag_index=1:(K+1):K^2;
    Diag_Omega=Diag_index(user_adm);
    [Diag_Omega_i, Diag_Omega_j] = ind2sub([K,K], Diag_Omega);
    Diag_Omega = sparse(Diag_Omega_i, Diag_Omega_j, 1, K, K);
    Omega=V+Diag_Omega; %sampling set for matrix completion
    % BM modifies
    params.omega = Omega;
    % [xsol, P, infos] = exhaustive_admission_algorithm(K, r, params);
    
    [xsol, P, infos] = user_admission_algorithm(user_adm, r, params,Omega);
    mycost = [infos.cost];
    Nres = sqrt(mycost(end)*2)/sqrt(sparsity);
    
end