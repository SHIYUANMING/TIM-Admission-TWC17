
cd mex_files

mex xpowy.c
mex xpowy2.c

cd ..