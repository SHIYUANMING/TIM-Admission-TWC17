Code title: "A Sparse and Low-Rank Optimization Framework for Index Coding via Riemannian Optimization"

Implementation of the Riemannian algorithm for low-rank and sparse decomposition.
(c) 2016-2017 Bamdev Mishra <bamdevm@gmail.com> and Yuanming Shi <shiym@shanghaitech.edu.cn>.

This package contains a MATLAB implementation of the algorithm presented in the report.

Yuanming Shi and Bamdev Mishra,
"A Sparse and Low-Rank Optimization Framework for Index Coding via Riemannian Optimization",
Technical report, arXiv:1604.04325, 2016.

This implementation is due to 
Bamdev Mishra <bamdevm@gmail.com>, 2016 and 
and Yuanming Shi <shiym@shanghaitech.edu.cn>.

The implementation is a research prototype still in development and is provided AS IS. 
No warranties or guarantees of any kind are given. Do not distribute this
code or use it other than for your own research without permission of the authors.

Feedback is greatly appreciated.



Installation:
-------------

- Set current directory as your current folder in Matlab or put it in your Matlab path.
- Run "run_me_first.m" to add folders to the working path. This needs to be done at the starting of each session.
- Run "install_mex.m" to compile mex files. This needs to be done only once.
- To check that everything works, run "test_Riemannian_algorithm.m" at Matlab command prompt (you should see a plot at the end).



Files:
------
- proposed/Riemannian_algorithm.m: the main wrapper file that implements the proposed Riemannian optimization algorithm. 



Disclaimer:
-----------

- All files are written by Bamdev Mishra and Yuanming Shi except 
    - mex files xpowy.c and xpowy2.c, which were written by Michel Journee <michel.journee@gmail.com >.

- Manopt is downloaded from http://manopt.org.


    


