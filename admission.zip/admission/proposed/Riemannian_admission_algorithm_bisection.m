function [xsol, P, infos, activeuser] = Riemannian_admission_algorithm_bisection(K, r, params, V)

    Diag_index=1:(K+1):K^2;
    user_adm=1:K;
    Diag_Omega=Diag_index(user_adm);
    [Diag_Omega_i, Diag_Omega_j] = ind2sub([K,K], Diag_Omega);
    Diag_Omega = sparse(Diag_Omega_i, Diag_Omega_j, 1, K, K);
    Omega=V+Diag_Omega; %sampling set for matrix completion
    % BM modifies
    [xsol, P, infos] = user_admission_algorithm(user_adm, r, params,Omega);
    mycost = [infos.cost];
    Nres = sqrt(mycost(end)*2)/sqrt(K);
    if Nres<params.costtol
        if params.verb==1
            fprintf('Feasible: A=%.2d, Nres=%3.6e \n',K,Nres);
       end
        activeuser=K;return;
    end
    % Input 
    
    rho = params.rho;
    eps = params.eps;

    lambda = params.lambda;
    
    %% Step 1: finding the sparsity pattern.
    if params.verbosity > 0
        fprintf('\n\t\t\t\t Step 1: finding the sparsity pattern.\n\n');
    end
    
    % Pick the manifold of fixed-rank matrices
    problem.M = fixedrankfactory_2factors_preconditioned(K, K, r); % Suits well to the diagonal constraint.
    
    problem.cost = @cost;
    function f = cost(x)
        L = x.L;
        R = x.R;
        
        f = -rho*sum(sum(((diag(L*R')).^2+eps^2).^(0.5))) ...
            + 0.5*norm(V.*(L*R'), 'fro')^2 ...
            + rho*lambda*norm(diag(L*R'), 'fro')^2;
  
    end
    
    problem.egrad = @egrad;
    function grad = egrad(x)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        
        grad.L = (diag(M) + S)*R;
        grad.R = (diag(M) + S)'*L;
    end
    
    problem.ehess = @ehess;
    function ehess = ehess(x, eta)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        Mdot = -rho*(LRt_sq_eps - xpowy2(3,LRt_sq_eps).*LRt_sq).*(diag(L*eta.R'+ eta.L*R'));
     
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        Sdot = V.*(L*eta.R'+ eta.L*R') +2*rho*lambda*diag(diag(L*eta.R'+ eta.L*R'));
        
        ehess.L = (diag(M) + S)*eta.R + (diag(Mdot)   +  Sdot)*R;
        ehess.R = (diag(M) + S)'*eta.L + (diag(Mdot') +  Sdot')*L;
    end
    
    %     % Check consistency of the gradient
    %     checkgradient(problem); pause;
    %     checkhessian(problem); pause;
    
    options.maxiter = params.maxiter;
    options.verbosity = params.verbosity;
    options.tolgradnorm = params.tolgradnorm;
    
    [xopt,~, infos_step1, ~] = trustregions(problem, [], options);
    Xopt = xopt.L*xopt.R';
    
    
    
    
    %% step 2: 
    %% Exhaustive search.
    
    [~,ind]=sort(abs(Xopt(Diag_index)),'descend');
    
    left_point = 1; right_point = K;
    while(1)
        sec_point = ceil((right_point+left_point)/2);
        user_adm=ind(1:sec_point);
        Diag_Omega=Diag_index(user_adm);
        [Diag_Omega_i, Diag_Omega_j] = ind2sub([K,K], Diag_Omega);
        Diag_Omega = sparse(Diag_Omega_i, Diag_Omega_j, 1, K, K);
        Omega=V+Diag_Omega; %sampling set for matrix completion
        % BM modifies
        [xsol, P, infos] = user_admission_algorithm(user_adm, r, params,Omega);
        mycost = [infos.cost];
        Nres = sqrt(mycost(end)*2)/sqrt(sec_point);
        
        if left_point>=right_point-1
           if Nres<params.costtol
               if params.verb==1
                    fprintf('Feasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
               end
               activeuser=sec_point;
           else
               if params.verb==1
                    fprintf('Infeasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
               end
               activeuser=sec_point-1;
           end
           break;
        else
            if Nres<params.costtol
                if params.verb==1
                    fprintf('Feasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
                end
                left_point = sec_point;
            else
                if params.verb==1
                    fprintf('Infeasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
                end
                right_point = sec_point-1;
            end
        end
        
    end
    
    xsol = xsol.U*xsol.V';
end