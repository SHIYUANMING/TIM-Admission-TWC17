function[Xsol, P, infos] = user_admission_algorithm(user_adm, r, params,V)
    % function exhaustive_admission_algorithm(K, r, params)
    %
    % Input:
    % K is the number of nodes/receivers/transmitters.
    % r is the rank.
    %
    % params.verbosity:  verbosity. Default is 2.
    % params.maxiter:    maximum number of T-R iterations. Default is 200.
    %
    %
    % Output:
    % xsol:             a structure with low-rank factors L and R.
    % infos:            structure containing the stats.
    %
    
    % Input
    user_adm = sort(user_adm,'ascend');
    Omega = V(user_adm,user_adm);
    K = length(user_adm);
    if r>K;r=K;end
    
    
    %% Exhaustive search.
    
    
    % Pick the manifold of fixed-rank matrices
    problem.M = fixedrankfactory_2factors_preconditioned(K, K, r); % Suits well to the diagonal constraint.
    
    
    if params.verbosity > 0
        fprintf('\n\n\t\t\t\t Exhaustive search.\n\n');
    end
    
    
    problem.cost = @cost_final;
    function f = cost_final(y)
        L = y.L;
        R = y.R;
        f = 0.5*norm(Omega.*(L*R') - Omega.*eye(K), 'fro')^2;
    end
    
    problem.egrad = @egrad_final;
    function grad = egrad_final(y)
        L = y.L;
        R = y.R;
        
        S = Omega.*(L*R' - eye(K));
        
        grad.L = S*R;
        grad.R = S'*L;
    end
    
    problem.ehess = @ehess_final;
    function ehess = ehess_final(y, eta)
        L = y.L;
        R = y.R;
        LdotR = eta.L*R';
        LRdot = L*eta.R';
        
        S = Omega.*(L*R' - eye(K));
        Sdot = Omega.*(LdotR + LRdot);
        
        ehess.L = S*eta.R + Sdot*R;
        ehess.R = S'*eta.L + Sdot'*L;
    end

    if ~isfield(params,'maxiter')
        options.maxiter = 300;
    else
        options.maxiter = params.maxiter;
    end
    
    if ~isfield(params,'verbosity')
        options.verbosity = 2;
    else
        options.verbosity = params.verbosity;
    end
    
    if ~isfield(params,'tolgradnorm')
        options.tolgradnorm = 1e-6;
    else
        options.tolgradnorm = params.tolgradnorm;
    end
    [xsol, ~, infos, ~] = trustregions(problem, [], options);
    Xsol = xsol.L*xsol.R';
    if params.verbosity > 0
        if K < 15
            display(Xsol);
        end
        fprintf('\nFinal L1 norm is %7.5e.\n',sum(sum(abs(Xsol))));
    end
    
    P = zeros(K, 1);
    P(abs(diag(Xsol)) > params.sparsity_tol) = 1; % Final thresholding: 1e-6 or 1e-8
end
