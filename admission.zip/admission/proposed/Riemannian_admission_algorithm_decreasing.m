function [xsol, P, infos, activeuser,user_adm] = Riemannian_admission_algorithm_decreasing(K, r, params, V, rho)

    % Input 

    eps = params.eps;
    lambda = params.lambda;
    if nargin<5
        rho = params.rho;
    end
    
    %% Step 1: finding the sparsity pattern.
    if params.verbosity > 0
        fprintf('\n\t\t\t\t Step 1: finding the sparsity pattern.\n\n');
    end
    
    % Pick the manifold of fixed-rank matrices
    problem.M = fixedrankfactory_2factors_preconditioned(K, K, r); % Suits well to the diagonal constraint.
    
    problem.cost = @cost;
    function f = cost(x)
        L = x.L;
        R = x.R;
        
        f = -rho*sum(sum(((diag(L*R')).^2+eps^2).^(0.5))) ...
            + 0.5*norm(V.*(L*R'), 'fro')^2 ...
            + rho*lambda*norm(diag(L*R'), 'fro')^2;
  
    end
    
    problem.egrad = @egrad;
    function grad = egrad(x)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        
        grad.L = (diag(M) + S)*R;
        grad.R = (diag(M) + S)'*L;
    end
    
    problem.ehess = @ehess;
    function ehess = ehess(x, eta)
        L = x.L;
        R = x.R;
        
        LRt = diag(L*R');
        LRt_sq = LRt.^2;
        LRt_sq_eps0 = LRt_sq + eps^2;
        LRt_sq_eps = xpowy(0.5, LRt_sq_eps0);
        M = -rho*LRt_sq_eps.*(LRt);
        Mdot = -rho*(LRt_sq_eps - xpowy2(3,LRt_sq_eps).*LRt_sq).*(diag(L*eta.R'+ eta.L*R'));
     
        S = V.*(L*R') + 2*rho*lambda*diag(diag(L*R'));
        Sdot = V.*(L*eta.R'+ eta.L*R') +2*rho*lambda*diag(diag(L*eta.R'+ eta.L*R'));
        
        ehess.L = (diag(M) + S)*eta.R + (diag(Mdot)   +  Sdot)*R;
        ehess.R = (diag(M) + S)'*eta.L + (diag(Mdot') +  Sdot')*L;
    end

    if ~isfield(params,'maxiter')
        options.maxiter = 300;
    else
        options.maxiter = params.maxiter;
    end
    
    if ~isfield(params,'verbosity')
        options.verbosity = 2;
    else
        options.verbosity = params.verbosity;
    end
    
    if ~isfield(params,'tolgradnorm')
        options.tolgradnorm = 1e-6;
    else
        options.tolgradnorm = params.tolgradnorm;
    end

    [xopt,~, infos_step1, ~] = trustregions(problem, [], options);
    Xopt = xopt.L*xopt.R';
    

    %% step 2: 
    %% search with admission priority.
    Diag_index=1:(K+1):K^2;
    [~,ind]=sort(abs(Xopt(Diag_index)),'descend');
    activeuser=0;
    for A = K:-1:1
        user_adm=ind(1:A);
        Diag_Omega=Diag_index(user_adm);
        [Diag_Omega_i, Diag_Omega_j] = ind2sub([K,K], Diag_Omega);
        Diag_Omega = sparse(Diag_Omega_i, Diag_Omega_j, 1, K, K);
        Omega=V+Diag_Omega; %sampling set for matrix completion
        % BM modifies
        [xsol, P, infos] = user_admission_algorithm(user_adm, r, params,Omega);
        mycost = [infos.cost];
        Nres = sqrt(mycost(end)*2)/sqrt(A);
        
       if Nres<params.costtol
           if params.verb==1
                fprintf('Feasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
           end
           activeuser = A;
           break;
       else
           if params.verb==1
                fprintf('Infeasible: A=%.2d, Nres=%3.6e \n',sec_point,Nres);
           end
       end
    end
end