function[xsol, P, infos, activeuser,user_adm] = exhaustive_admission_algorithm(K, r, params, V)
    if nargin<4
        V = params.omega;
    end
    if ~isfield(params,'maxiter'); params.maxiter = 300; end; 
    Diag_index=1:(K+1):K^2;
    
    %% Exhaustive search.
    
    for A=K:-1:1
        
        user_adm=nchoosek([1:K],A);
        feasible_temp=0; %feasibility counter
        
        for s=1:nchoosek(K,A)
            
            Diag_Omega=Diag_index(user_adm(s,:));
            [Diag_Omega_i, Diag_Omega_j] = ind2sub([K,K], Diag_Omega);
            Diag_Omega = sparse(Diag_Omega_i, Diag_Omega_j, 1, K, K, A);
            Omega=V+Diag_Omega; %sampling set for matrix completion
            [xsol, P, infos] = user_admission_algorithm(user_adm(s,:), r, params, Omega);
            mycost = [infos.cost];
            Nres = sqrt(mycost(end)*2)/sqrt(A);
            %fprintf('A=%.2d, s=%.3d, Nres=%3.6e \n',A,s,Nres);
            if Nres<params.costtol
                %fprintf('Feasible: A=%.2d, s=%.3d, Nres=%3.6e \n',A,s,Nres);
                feasible_temp=1;
                break;
            end
        end
        
        if feasible_temp>0 %all the available sets are infeasible
            break;
        end
    end
    
    if feasible_temp==0
        activeuser=0;user_adm=[];
    else
        activeuser=A;
        user_adm=user_adm(s,:);
    end