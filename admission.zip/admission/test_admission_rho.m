%% This script is used to test the impact of different values of rho. manuscript is saved in 07/20/2016.

clear ; clc; %close all;
randn('seed',20);rand('seed',20);
K = 8;
Interfer_link = 45;
rank_init = 1;
rank_final = K;
ranksize = rank_final-rank_init+1;

SS = 500;

rho_set = [1e-3, 0.1, 10];
interfer_set = 20:2:56;
interfer_len = length(interfer_set);
rho_len = length(rho_set);

params.maxiter = 300;
params.verb=0;
params.verbosity = 0;
params.tolgradnorm = 1e-11;
params.tol = 1e-6;
params.costtol=1e-3;
params.sparsity_tol=1e-11;

params.eps = 1e-3;
params.lambda = 0.5;

sparsity_vec_aver = zeros(interfer_len,rho_len);
exh_sparsity_vec_aver = zeros(interfer_len,1);
r = 4;
%r = 3;
tic

parfor ss = 1:SS
    sparsity_vec = zeros(interfer_len,rho_len);
    exh_sparsity_vec = zeros(interfer_len,1);
    for rlinks = 1:interfer_len
        interlinks = interfer_set(rlinks);
        V = make_rand_Omega(K, interlinks);
        for rrho = 1:rho_len
            rho = rho_set(rrho);
            % Run Riemannian algorithm
            [xsol, P, infos, sparsity]=Riemannian_admission_algorithm_decreasing(K, r, params,V,rho);
            sparsity_vec(rlinks,rrho) = sparsity;
            fprintf('Test: %.3d, lambda=%.2f, links=%.3d, Proposed: sparsity=%.2d \n',ss, rho, interlinks, sparsity);
        end
        [exh_xsol, exh_P, exh_infos, exh_user,exh_user_adm]=exhaustive_admission_algorithm(K, r, params,V);
        exh_sparsity_vec(rlinks) = exh_user;
    end
    sparsity_vec_aver = sparsity_vec_aver+sparsity_vec/SS;
    exh_sparsity_vec_aver = exh_sparsity_vec_aver+exh_sparsity_vec/SS;
end
t=toc
%% Plots

result_sparsity = sparsity_vec_aver; result_sparsity(end,:)=r;

fs = 14;        
figure;
plot(interfer_set, result_sparsity, '-d','LineWidth',1.2, 'MarkerSize',10);hold on
plot(interfer_set, exh_sparsity_vec_aver,'k-d','LineWidth',1.2, 'MarkerSize',10);
xlim([min(interfer_set), max(interfer_set)]);
hold on;
ax1 = gca;
set(ax1,'FontSize',fs);
xlabel('\rho','FontSize',fs);
ylabel('Admitted Users','FontSize',fs);
title(['K = ', num2str(K), ', r = ',num2str(r) ', tol=' num2str(params.costtol) ', eps=' num2str(params.eps)]);
legend('1e-3', '0.1', '10','exhausted');
box off;
