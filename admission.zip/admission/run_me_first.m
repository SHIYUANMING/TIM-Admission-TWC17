% Add folders to path.


addpath(pwd);

cd manopt;
addpath(genpath(pwd));
cd ..;

cd mex_files/;
addpath(genpath(pwd));
cd ..;


cd proposed/;
addpath(genpath(pwd));
cd ..;
